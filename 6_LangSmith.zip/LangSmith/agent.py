import os 
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph,START,END
from langgraph.graph import add_messages
from typing import Annotated,TypedDict
from dotenv import load_dotenv
load_dotenv
api=os.getenv("GROQ_API_KEY")
llm=ChatGroq(model='llama-3.1-8b-instant',api_key=api)

#CREATE STATE
class State(TypedDict):
    messages:Annotated[list,add_messages]


#Create Node
def llm_node(state:State):
    return {'messages':llm.invoke(state['messages'])}

#Graph 
def create_graph():
    builder=StateGraph(State)
    #add nodes 
    builder.add_node("llm_node",llm_node)
    #add edges
    builder.add_edge(START,"llm_node")
    builder.add_edge("llm_node",END)
    #Compile 
    graph=builder.compile()
    return graph 

function_name=create_graph()


